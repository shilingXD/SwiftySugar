//
//  TestFile.swift
//  LocalizationEditorTests
//
//  Created by Igor Kulman on 16/12/2018.
//  Copyright © 2018 Igor Kulman. All rights reserved.
//

import Foundation

struct TestFile {
    let originalFileName: String
    let destinationFileName: String
    let destinationFolder: String
}
